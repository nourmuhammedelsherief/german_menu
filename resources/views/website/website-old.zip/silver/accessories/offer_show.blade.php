
<div class="content mb-0">
    <div class="xicon ">
        <a href="#"
        class="close-menu">
            <i class="fa fa-times" ></i>
        </a>
    </div>     
	<img id="offer-image" src="" alt="" style="width: 100%;">
</div>

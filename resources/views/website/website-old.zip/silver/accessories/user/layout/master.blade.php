@include('website.'.session('theme_path').'silver.accessories.user.layout.header')
<section id="breadc">
    <div class="home-breadc-area">
        <div class="container">
            <div class="section-heading-1 home-about-text" style="text-align: center;">
                <h3 style="display: block;">تسجيل عضوية جديدة  </h3>
            </div>
        </div>
    </div>
</section>
<div class="barcode">
    <p>امسح البار كود لتجربة المنيو</p>
    <img src="{{asset('Auth_images/bc.png')}}"/>
</div>





<section style="padding-top: 20px">
    <div class="portfolio-area">
        <div class="container">
            <div class="row new-item-slider" dir="ltr">
                <!--single sld item-->
                <div class="single-portfolio-item" >
                    <div style="max-width: 80%; margin:auto;">
                        <img src="{{asset('Auth_images/imgnew.png')}}" alt="">
                        <div style="padding-top: 35px;">
                            <h3 style="padding-top: 12px;">تحديث موقع ايزي منيو</h3>
                            <p>
                                هذا النص هو مثال لنص يمكن ان يستبدل في نفس المساحة. لقد تم توليد هذا النص من مولد النص العربي هذا النص هو مثال لنص يمكن ان يستبدل في نفس المساحة. لقد تم توليد هذا النص من مولد النص العربي
                            </p>
                        </div>
                    </div>
                </div>

                <!--single sld item-->
                <div class="single-portfolio-item" >
                    <div style="max-width: 80%; margin:auto;">
                        <img src="{{asset('Auth_images/imgnew.png')}}" alt="">
                        <div style="padding-top: 35px;">
                            <h3 style="padding-top: 12px;">تحديث موقع ايزي منيو</h3>
                            <p>
                                هذا النص هو مثال لنص يمكن ان يستبدل في نفس المساحة. لقد تم توليد هذا النص من مولد النص العربي هذا النص هو مثال لنص يمكن ان يستبدل في نفس المساحة. لقد تم توليد هذا النص من مولد النص العربي
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



@yield('content')

<div class="container" style="margin-bottom: 60px;">
    <div class="txt-center logtitle">
        <h3 style="padding-top: 12px;padding-bottom: 30px;">عملاؤنا  </h3>

    </div>

    <div class="row">
        <div class="col-md-12 hidemob">
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/atyaf-cafe">
                                <img src="https://easymenu.site/uploads/slidersUser/160937562960706.png" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/CalmaCafe">
                                <img src="https://easymenu.site/uploads/slidersUser/161349088146999.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/TastyDip">
                                <img src="https://easymenu.site/uploads/slidersUser/160972047884611.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Shrimp-attack">
                                <img src="https://easymenu.site/uploads/slidersUser/161349558247126.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/20UR">
                                <img src="https://easymenu.site/uploads/slidersUser/160971787594299.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/WakaWaka">
                                <img src="https://easymenu.site/uploads/slidersUser/160971833594952.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/MangoMix">
                                <img src="https://easymenu.site/uploads/slidersUser/160972138965157.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/OceanCoffee">
                                <img src="https://easymenu.site/uploads/slidersUser/160971790224705.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/VigorCoffee">
                                <img src="https://easymenu.site/uploads/slidersUser/160972035367418.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/loqmat_baladna">
                                <img src="https://easymenu.site/uploads/slidersUser/161349141040315.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Rise%20Bakery">
                                <img src="https://easymenu.site/uploads/slidersUser/160972083756472.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/KIms">
                                <img src="https://easymenu.site/uploads/slidersUser/164286206740146.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/BigBCoffee">
                                <img src="https://easymenu.site/uploads/slidersUser/161350965488656.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Hydrogen">
                                <img src="https://easymenu.site/uploads/slidersUser/160971904246697.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ShrimpRush">
                                <img src="https://easymenu.site/uploads/slidersUser/161349018717260.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ChitzaCafe">
                                <img src="https://easymenu.site/uploads/slidersUser/160972226917854.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/SpecialtyKof">
                                <img src="https://easymenu.site/uploads/slidersUser/161349471744607.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/AfranAlhaneth">
                                <img src="https://easymenu.site/uploads/slidersUser/161349514850218.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/SeaBuckeet">
                                <img src="https://easymenu.site/uploads/slidersUser/160972071416977.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/TriangleHouse">
                                <img src="https://easymenu.site/uploads/slidersUser/160971800582494.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/911_Restaurant">
                                <img src="https://easymenu.site/uploads/slidersUser/160972175820344.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/BaitLaymona">
                                <img src="https://easymenu.site/uploads/slidersUser/160971952650571.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ArabicaCorner">
                                <img src="https://easymenu.site/uploads/slidersUser/160971864186634.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ChocolateFallsCafe">
                                <img src="https://easymenu.site/uploads/slidersUser/160971882656283.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Noumi">
                                <img src="https://easymenu.site/uploads/slidersUser/160971939641727.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/TmiratCafe">
                                <img src="https://easymenu.site/uploads/slidersUser/161350797038310.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/DhadSpecialityCoffee">
                                <img src="https://easymenu.site/uploads/slidersUser/160971981687560.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/HasaSteak&amp;Grill">
                                <img src="https://easymenu.site/uploads/slidersUser/160972057318761.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/easyMenuu">
                                <img src="https://easymenu.site/uploads/slidersUser/160950719219366.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/N2">
                                <img src="https://easymenu.site/uploads/slidersUser/161350273547361.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/InnovationBurger">
                                <img src="https://easymenu.site/uploads/slidersUser/161350330837311.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Alkeet">
                                <img src="https://easymenu.site/uploads/slidersUser/161350548417177.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/AddictionCoffee">
                                <img src="https://easymenu.site/uploads/slidersUser/161350763364913.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/DeerCafe">
                                <img src="https://easymenu.site/uploads/slidersUser/162170872337661.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Shrimpail">
                                <img src="https://easymenu.site/uploads/slidersUser/162170915531079.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Marigolds">
                                <img src="https://easymenu.site/uploads/slidersUser/162170974382254.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Lute">
                                <img src="https://easymenu.site/uploads/slidersUser/162171001165294.png" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/mhashi_frahat">
                                <img src="https://easymenu.site/uploads/slidersUser/162171056760365.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/TUXEDO_RESTAURANT_AND_CAFE">
                                <img src="https://easymenu.site/uploads/slidersUser/162171064082266.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Sideburns_enough">
                                <img src="https://easymenu.site/uploads/slidersUser/162186347299385.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Dha">
                                <img src="https://easymenu.site/uploads/slidersUser/162186416581093.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Kangaroo">
                                <img src="https://easymenu.site/uploads/slidersUser/162186486848329.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ghasaq_coffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162186493621001.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/The_Tone">
                                <img src="https://easymenu.site/uploads/slidersUser/162186499128964.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Volcanokebabs">
                                <img src="https://easymenu.site/uploads/slidersUser/162186520681791.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Rickeys_Speciality_Coffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162186575468241.png" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/chillax">
                                <img src="https://easymenu.site/uploads/slidersUser/162186592897013.jpg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/The_X_coffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162637448683473.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Lafaeff">
                                <img src="https://easymenu.site/uploads/slidersUser/162637470383598.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ROSHETA_COFFEE">
                                <img src="https://easymenu.site/uploads/slidersUser/162637479168943.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/City_Sandwich">
                                <img src="https://easymenu.site/uploads/slidersUser/162637500389406.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Graphite">
                                <img src="https://easymenu.site/uploads/slidersUser/162637510435429.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Coffee_night">
                                <img src="https://easymenu.site/uploads/slidersUser/162637526397420.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/FUSE">
                                <img src="https://easymenu.site/uploads/slidersUser/162637534747590.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/LocationCoffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162637542994860.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Panache_Live_Grill">
                                <img src="https://easymenu.site/uploads/slidersUser/162637564737286.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/ROSSA">
                                <img src="https://easymenu.site/uploads/slidersUser/162637594421311.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Hazzat_Hala">
                                <img src="https://easymenu.site/uploads/slidersUser/162637600276408.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Taraf_Cafe">
                                <img src="https://easymenu.site/uploads/slidersUser/162637611355783.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Victoria_cafe">
                                <img src="https://easymenu.site/uploads/slidersUser/162637619871064.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Solar_coffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162637622624112.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/CRAVING">
                                <img src="https://easymenu.site/uploads/slidersUser/162637633124581.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Elgringo_Aliraqi">
                                <img src="https://easymenu.site/uploads/slidersUser/162637638596133.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/BG_coffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162637648061934.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Roseyana_Caffe">
                                <img src="https://easymenu.site/uploads/slidersUser/162637653814169.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Lute">
                                <img src="https://easymenu.site/uploads/slidersUser/162637661726507.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Flowers_beach_cafe">
                                <img src="https://easymenu.site/uploads/slidersUser/162637667959583.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/BMS">
                                <img src="https://easymenu.site/uploads/slidersUser/162637673011952.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Loop_coffee">
                                <img src="https://easymenu.site/uploads/slidersUser/162637682555296.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Balensia_Cafe">
                                <img src="https://easymenu.site/uploads/slidersUser/162637690996776.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/dimato_cafe">
                                <img src="https://easymenu.site/uploads/slidersUser/162637716312589.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/KIms">
                                <img src="https://easymenu.site/uploads/slidersUser/164286217012924.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Kims">
                                <img src="https://easymenu.site/uploads/slidersUser/164286227717198.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/AYO">
                                <img src="https://easymenu.site/uploads/slidersUser/164286288965956.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Sharq">
                                <img src="https://easymenu.site/uploads/slidersUser/164286302052575.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/CALIENTE_LOUNGE">
                                <img src="https://easymenu.site/uploads/slidersUser/164286312435059.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="themesflat-partner style-2 align-center clearfix" style="width:80px; height:80px;float:right; margin:7px;">
                <div class="partner-item">
                    <div class="innerx">
                        <div class="thumbxx">
                            <a href="https://easymenu.site/restaurants/Naveena_Restaurant">
                                <img src="https://easymenu.site/uploads/slidersUser/164286319357855.jpeg" alt="Image" style="border-radius:50%; border:3px solid #fea702; width: 100%; height:80px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

</div>


<!-- =========Footer Area=========== -->
<section id="footer-fixed">
    <div class="big-footer">
        <div class="container">
            <div class="row">
                <!--footer logo-->
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                            <img src="{{asset('Auth_images/fimg.png')}}" />
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                            <h3 class="footitle"> محتوي تجريبي هنا</h3>
                            <a href="#"> <img src="{{asset('Auth_images/google.png')}}" class="download" /></a>
                            <a href="#"> <img src="{{asset('Auth_images/apple.png')}}"  class="download" /></a>
                        </div>
                    </div>

                </div>
                <!--footer quick links-->
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">

                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                            <a href="#" class="foobtn">
                                <span>المبيعات</span>
                                05000000000
                            </a>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                            <a href="#" class="foobtn">
                                <span>الدعم الفني</span>
                                05000000000
                            </a>
                        </div>

                    </div>


                    <div class="row">
                        <div class="col-xl-12">
                            <div class="contact-form-area" data-aos="flip-up" data-aos-delay="0" data-aos-duration="1000">
                                <!--contact left bg-->
                                <div class="section-heading-1 cont4 home-about-text" style="text-align: right;margin-bottom: 10px;">

                                    <h3 style="color: #fff;font-size: 18px;">  تواصل معنا </h3>

                                </div>
                                <div class="contact-form">
                                    <form action="#">
                                        <input class="fooform" type="text" placeholder=" الاسم">
                                        <input class="fooform margin-top-lb-30 margin-top-sb-30" type="email" placeholder=" البريد الالكتروني">
                                        <input  type="text" class="fooform subject" placeholder="عنوان الرسالة">
                                        <textarea class="fooform" placeholder="موضوع الرسالة    "></textarea>
                                        <div class="send-btn">
                                            <input type="submit" value="ارسال الرسالة" id="formsend">
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>



                </div>


            </div>
        </div>
    </div>
    <!--copyright-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-xl-6 text-right">
                    <p>جميع الحقوق محفوظة لدى ايزي منيو   &copy; 2022</p>
                </div>
                <div class="col-xl-6 text-left">

                </div>

            </div>
    </footer>
</section>
@include('website.'.session('theme_path').'silver.accessories.user.layout.scripts')




<!-- Jquery JS -->
<script src="{{asset('Auth_js/vendor/jquery-2.2.4.min.js')}}"></script>
<!-- Proper JS -->
<script src="{{asset('Auth_js/popper.min.js')}}"></script>
<!-- Bootstrap Js -->
<script src="{{asset('Auth_js/bootstrap.min.js')}}"></script>
<!-- Video popup Js -->
<script src="{{asset('Auth_js/magnific-popup.min.js')}}"></script>
<!-- Waypoint Up Js -->
<script src="{{asset('Auth_js/waypoints.min.js')}}"></script>
<!-- Counter Up Js -->
<script src="{{asset('Auth_js/counterup.min.js')}}"></script>
<!-- Meanmenu Js -->
<script src="{{asset('Auth_js/meanmenu.min.js')}}"></script>
<!-- Animation Js -->
<script src="{{asset('Auth_js/aos.min.js')}}"></script>
<!-- Filtering Js -->
<script src="{{asset('Auth_js/isotope.min.js')}}"></script>
<!-- Background Move Js -->
<script src="{{asset('Auth_js/jquery.backgroundMove.js')}}"></script>
<!-- Slick Carousel Js -->
<script src="{{asset('Auth_js/slick.min.js')}}"></script>
<!-- ScrollUp Js -->
<script src="{{asset('Auth_js/scrollUp.js')}}"></script>
<!-- Main Js -->
<script src="{{asset('Auth_js/main.js')}}"></script>
</body>

</html>
